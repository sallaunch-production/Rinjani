"use client";
import { Payment, columns } from "./columns";
import { DataTable } from "./data-table";
import axios from "axios";
import Cookies from "js-cookie";
import { jwtDecode } from "jwt-decode";

import { redirect } from "next/navigation";
import { useEffect, useState } from "react";
import * as XLSX from "xlsx";
export default function Page({ params }: { params: { detail: string } }) {
  const [dataq, setData] = useState<any[]>([]);
  const [period, setPeriod] = useState("");
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    const token = Cookies.get("token");
    const plaintext = jwtDecode(token as string) as any;
    if (
      plaintext.roles.some(function (el: any) {
        return el.name !== "approver";
      })
    ) {
      redirect("/dashboard");
    }
    var paramsa = {
      status: "1",
    };
    const isi_detail = params.detail.split("-");
    if (isi_detail[0] === "today") {
      paramsa = {
        status: "2",
      };
      const period =
        new Date().getDate() +
        " " +
        new Date().toLocaleString("default", { month: "long" }) +
        " " +
        new Date().getFullYear();
      setPeriod(period);
    } else if (isi_detail[0] === "month") {
      paramsa = {
        status: "1",
      };
      const period =
        new Date().toLocaleString("default", { month: "long" }) +
        " " +
        new Date().getFullYear();
      setPeriod(period);
    }
    const data_country = axios
      .post(
        `${process.env.NEXT_PUBLIC_API_URL}/api/list-transaction-ok`,
        params,
        {
          headers: {
            Authorization: "Bearer " + Cookies.get("token"), //the token is a variable which holds the token
          },
        }
      )

      .then((response) => {
        const array_empty: any[] = [];

        response.data.transaksi_send_temp.map((post: any) =>
          array_empty.push(post)
        );
        setData(array_empty);
      })
      .catch((error) => {});
  }, []);

  const onGetExporProduct = async (title?: string, worksheetname?: string) => {
    try {
      setLoading(true);
      // Check if the action result contains data and if it's an array
      if (dataq && Array.isArray(dataq)) {
        const dataToExport = dataq.map((pro: any) => ({
          "Nama Pengirim": pro.nama_pengirim,
          "Nama Penerima": pro.nama_penerima,
          Amount: pro.amount,
          "No. Referensi": pro.no_referensi,
          Identitas: pro.identitas,
          "No. Identitas": pro.nomor_identitas,
          "Tanggal Lahir": pro.tanggal_lahir,
          "Tempat Lahir": pro.tempat_lahir,
          Hubungan: pro.hubungan_pengirim,
          Pekerjaan: pro.pekerjaan,
          "Tujuan Penggunaan Dana": pro.tujuan_penggunaan_dana,
          "Sumber Dana": pro.sumber_dana,

          "Kode Pos": pro.kode_pos,
          "Jenis Kelamin": pro.jenis_kelamin,
          "Negara Tujuan": pro.negara_penerima,
          "Negara Penerbit ID": pro.photoidcountry,
          "Receive Amount": pro.receive_amount,
          Currency: pro.currency,
          "Telepon Pengirim": pro.telpon_pengirim,
          "Alamat Pengirim": pro.alamat_pengirim,
          "Kota Pengirim": pro.kota_pengirim,
          "Provinsi Pengirim": pro.provinsi_pengirim,
          "Kode Pos Pengirim": pro.kode_pos_pengirim,
          "Alamat Penerima": pro.alamat_penerima,
          "Telepon Penerima": pro.telepon_penerima,
          "Kota Penerima": pro.kota_penerima,
          "Total Collect Amounnt": pro.total_collect_amount,
          "Expected Date": pro.expected_date,
          "Agent Name": pro.receive_abb_name,
          "Alamat Domisili": pro.alamat_domisili_pengirim,
          "Kota Domisili": pro.kota_domisili_pengirim,
          "Kode DOmisili": pro.kode_pos_domisili_pengirim,
          "Provinsi Domisili": pro.provinsi_domisili_pengirim,
          "Data Rekening": pro.account_id,
          "Field Values": pro.field_values,
        }));
        // Create Excel workbook and worksheet
        const workbook = XLSX.utils.book_new();
        const worksheet = XLSX.utils?.json_to_sheet(dataToExport);
        XLSX.utils.book_append_sheet(workbook, worksheet, worksheetname);
        // Save the workbook as an Excel file
        XLSX.writeFile(workbook, `${title}.xlsx`);
        console.log(`Exported data to ${title}.xlsx`);
        setLoading(false);
      } else {
        setLoading(false);
        console.log("#==================Export Error");
      }
    } catch (error: any) {
      setLoading(false);
      console.log("#==================Export Error", error.message);
    }
  };
  return (
    <div className="card">
      <div className="card-body">
        <button
          onClick={() => onGetExporProduct("Send - " + period, "Send")}
          className="w-40 ml-5 mt-3 mb-3 btn btn-success px-3 text-white transition hover:bg-red-800"
        >
          <span className="relative">{loading ? "Loading..." : "Export"}</span>
        </button>
        <h2 className="text-2xl mt-3">List All Send Transactions</h2>
      </div>

      <div className="container mx-auto">
        <div></div>
        <h3>Period: {period}</h3>
        <DataTable columns={columns} data={dataq} />
      </div>
    </div>
  );
}
